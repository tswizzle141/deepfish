import cv2
import os
import json

count = 0
path = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/yolov5/Bee/HoneyBee/"
# dirs = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/train/"
for root, dirs, files in os.walk(path):
    for file in files:
        path_image = os.path.join(path, file)
        image = cv2.imread(path_image)
        image = cv2.resize(image, (416, 416))
        cv2.imwrite(os.path.join(path, "{:06d}.jpg".format(count)), image)
        count += 1


# path = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/nghich1/"
# for root, dirs, files in os.walk(path):
#     for file in files:
#         json_files = os.path.join(root, file)
#         json_data = json.load(open(json_files))
#
#         print(json_data)
