import cv2
import os

a = []
b = []
count = 0
path_gt = "F:/Database/Bee/evaluate_track/id1_concat/gt/"
path_track = "F:/Database/Bee/evaluate_track/id1_concat/track/"
path_save = "F:/Database/Bee/evaluate_track/id1_concat/combine/"
for file in os.listdir(path_gt):
    if file.endswith(".jpg"):
        a.append(file)

for file in os.listdir(path_track):
    if file.endswith(".jpg"):
        b.append(file)

print(len(a))
print(len(b))
for i in range(max(len(a), len(b))):
    if i < min(len(a), len(b)):
        path_img1 = os.path.join(path_gt, a[i])
        path_img2 = os.path.join(path_track, b[i])
        img1 = cv2.imread(path_img1)
        img2 = cv2.imread(path_img2)
        img1 = cv2.resize(img1, (640, 720))
        img2 = cv2.resize(img2, (640, 720))
        img = cv2.hconcat([img1, img2])
        cv2.imshow("img", img)
        cv2.waitKey(10)
        cv2.imwrite(os.path.join(path_save, "{:06d}.jpg".format(count)), img)
        count += 1
    elif len(a) < len(b):
        path_img1 = os.path.join(path_gt, a[len(a) - 1])
        path_img2 = os.path.join(path_track, b[i])
        img1 = cv2.imread(path_img1)
        img2 = cv2.imread(path_img2)
        img1 = cv2.resize(img1, (640, 720))
        img2 = cv2.resize(img2, (640, 720))
        img = cv2.hconcat([img1, img2])
        cv2.imshow("img", img)
        cv2.waitKey(10)
        cv2.imwrite(os.path.join(path_save, "{:06d}.jpg".format(count)), img)
        count += 1
    else:
        path_img1 = os.path.join(path_gt, a[i])
        path_img2 = os.path.join(path_track, b[len(b) -1])
        img1 = cv2.imread(path_img1)
        img2 = cv2.imread(path_img2)
        img1 = cv2.resize(img1, (640, 720))
        img2 = cv2.resize(img2, (640, 720))
        img = cv2.hconcat([img1, img2])
        cv2.imshow("img", img)
        cv2.waitKey(10)
        cv2.imwrite(os.path.join(path_save, "{:06d}.jpg".format(count)), img)
        count += 1