import cv2
import argparse
import os
import shutil
import torch


def annotation(opt, *args):
    path, fps = opt.path, opt.fps
    path_images = path.split(".MP4")[0]

    # shutil.rmtree(path_images)
    os.mkdir(path_images)
    count = 0
    pos_frame = 0
    cap = cv2.VideoCapture(path)
    while cap.isOpened():
        ret, frame = cap.read()
        if ret:
            cv2.imshow("Video", frame)
            cv2.imwrite(os.path.join(path_images, "GH010371_{:05d}.jpg".format(count)), frame)
            cv2.waitKey(1)
            pos_frame += int(fps)
            count += 1
            cap.set(1, pos_frame)
        else:
            cap.release()
            break
    cap.release()


if __name__ == "__main__":
    parse = argparse.ArgumentParser()
    parse.add_argument("--path", type=str, help="path to video")
    parse.add_argument("--fps", type=int, default=1, help="fps")
    args = parse.parse_args()
    print(args)
    with torch.no_grad():
        annotation(args)
