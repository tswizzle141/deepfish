import cv2
import numpy as np
import os
import pandas as pd
import shutil

insert = 0
count = 0
path_coordinates = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/coordinate/Crawling/"
path_images = "C:\\Users\\Administrator\\Desktop\\Linh tinh\\Dataset\\HoneyBee\\"
Bee = cv2.imread("Bee.jpg")
Bee = cv2.resize(Bee, (20, 18))
Bee_flip = cv2.flip(Bee, 1)
img = np.zeros([720, 1280, 3], dtype=np.uint8)
img.fill(255)
img = cv2.line(img, (192, 231), (829, 232), color=(255, 0, 0), thickness=5)
img = cv2.line(img, (829, 233), (1055, 240), color=(255, 0, 0), thickness=5)
img = cv2.line(img, (1055, 240), (1280, 250), color=(255, 0, 0), thickness=5)

# cv2.imshow("img", img)
# cv2.waitKey(0)
# coor = []
# name_list = []


# for file in os.listdir(path_coordinates):
#     if file.endswith(".txt"):
#         name_list.append(file)
#
# for name in name_list:
#     path_file = path_coordinates + name
#     data = pd.read_csv(path_file, sep='\n', header=None, engine='python')
#     for i in range(len(data)):
#         coordinate = data[0][i]
#         b = coordinate.split(" ")
#         coor.append(b)
#         coor[i][0] = int(coor[i][0])
#         coor[i][1] = int(coor[i][1])
#
#     print(coor)
#
#     for j in range(len(coor) - 1):
#         # x = coor[j][0]
#         # y = coor[j][1]
#         h, w = Bee.shape[:2]
#         b, a, frame = coor[j][0], coor[j][1], int(coor[j][2])
#         y, x = a - int(h / 2), b - int(w / 2)
#         path_insert = path_images + "{:06d}.jpg".format(frame)
#         insert = cv2.imread(path_insert)
#         insert = cv2.circle(insert, (b, a), radius=11, color=(0, 255, 0), thickness=-1)
#         insert = cv2.resize(insert, (360, 200))
#         h1, w1 = insert.shape[:2]  # 875, 22
#         c, d = 875, 22
#         img = cv2.line(img, (coor[j][0], coor[j][1]), (coor[j + 1][0], coor[j + 1][1]), color=(0, 255, 0), thickness=5)
#         img1 = img.copy()
#         img[y:y + h, x:x + w] = Bee
#         img[d:d + h1, c:c + w1] = insert
#         cv2.imwrite(os.path.join(path_coordinates, "{:06d}.jpg".format(count)), img)
#         count += 1
#         cv2.imshow("img", img)
#         cv2.waitKey(500)
#         img = img1
#     j += 1
#     b, a, frame = coor[j][0], coor[j][1], int(coor[j][2])
#     path_insert = path_images + "{:06d}.jpg".format(frame)
#     insert = cv2.imread(path_insert)
#     insert = cv2.circle(insert, (b, a), radius=11, color=(0, 255, 0), thickness=-1)
#     insert = cv2.resize(insert, (360, 200))
#     h1, w1 = insert.shape[:2]  # 875, 22
#     c, d = 875, 22
#     img[d:d + h1, c:c + w1] = insert
#     cv2.imwrite(os.path.join(path_coordinates, "{:06d}.jpg".format(count)), img)
#     count += 1
#     cv2.imshow("img", img)
#     cv2.waitKey(500)
#
#     # for k in range(len(coor) - 2, len(coor) - 1):
#     #     h, w = Bee.shape[:2]
#     #     b, a = coor[k][0], coor[k][1]
#     #     y, x = a - int(h / 2), b - int(w / 2)
#     #     img = cv2.arrowedLine(img, (coor[k][0], coor[k][1]), (coor[k + 1][0], coor[k + 1][1]), color=(2, 255, 0),
#     #                           thickness=5, tipLength=0.2)
#     #     img1 = img.copy()
#     #     img[y:y + h, x:x + w] = Bee
#     #     # cv2.imwrite(os.path.join(path_coordinates, "{:06d}.jpg".format(count)), img)
#     #     # count += 1
#     #     cv2.imshow("img", img)
#     #     cv2.waitKey(500)
#     #     img = img1
#
#     coor = []
