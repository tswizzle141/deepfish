import os
import cv2
import json
import numpy as np

# from track import rectangle

path_gt = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/Track_image"
path_gt_annotations = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/HoneyBee_Annotations"
path_track = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/yolov5/yolov5-sort/HoneyBee"
path_track_txt = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/yolov5/yolov5-sort/results.txt"
save_gt = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/yolov5/evaluate_track/id_16/gt"
save_track = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/yolov5/evaluate_track/id_14/track"
a = []
b = []
c = []


# img = np.zeros([720, 1280, 3], dtype=np.uint8)
# img.fill(255)
# img = cv2.line(img, (192, 231), (829, 232), color=(255, 0, 0), thickness=5)
# img = cv2.line(img, (829, 233), (1055, 240), color=(255, 0, 0), thickness=5)
# img = cv2.line(img, (1055, 240), (1280, 250), color=(255, 0, 0), thickness=5)
# file_gt = open("C:/Users/Administrator/Desktop/Linh tinh/Dataset/yolov5/evaluate_track/id_14/gt/gt.txt")
# file_gt_data = file_gt.readlines()
# list_points = []
# count = 445
# v = 0
# for line in file_gt_data:
#     data = [x for x in line.split(" ")]
#     frame_ids = int(data[0])
#     x = int(data[1])
#     y = int(data[2])
#     pt = [x, y]
#     list_points.append(pt)
#     if len(list_points) <= 1:
#         cv2.imshow("img", img)
#         cv2.waitKey(3)
#     else:
#         print(len(list_points))
#         img = cv2.line(img, (list_points[len(list_points) - 2][0], list_points[len(list_points) - 2][1]),
#                        (list_points[len(list_points) - 1][0], list_points[len(list_points) - 1][1]), color=(0, 255, 0),
#                        thickness=5)
#         cv2.imshow("img", img)
#         cv2.waitKey(3)
#
# file_track = open("C:/Users/Administrator/Desktop/Linh tinh/Dataset/yolov5/evaluate_track/id_14/track/track.txt")
# file_track_data = file_track.readlines()
# list_points = []
# for line in file_track_data:
#     data1 = [x for x in line.split(" ")]
#     frame_ids1 = int(data1[0])
#     x1 = int(data1[1])
#     y1 = int(data1[2])
#     pt1 = [x1, y1]
#     list_points.append(pt1)
#     if len(list_points) <= 1:
#         cv2.imshow("img", img)
#         cv2.waitKey(3)
#     else:
#         img = cv2.line(img, (list_points[len(list_points) - 2][0], list_points[len(list_points) - 2][1]),
#                        (list_points[len(list_points) - 1][0], list_points[len(list_points) - 1][1]), color=(0, 0, 255), thickness=5)
#         cv2.imshow("img", img)
#         cv2.waitKey(3)
# while (v < 21):
#     cv2.imwrite(os.path.join(save_track, "{:06d}.jpg".format(count)), img)
#     count += 1
#     v += 1
# ----------------------------------------------------------------------------------------------------------------------------

def get_txt_track(path, path0, lists0, id):
    f = open(path)
    file_data = f.readlines()
    for line in file_data:
        data = [x for x in line.split(",")]
        frame_id = int(data[0])
        label = int(float(data[9].split("\n")[0]))
        if label == id:
            x_min = abs(round(int(float(data[1]))))
            y_min = abs(round(int(float(data[2]))))
            x_max = abs(round(int(float(data[3]))))
            y_max = abs(round(int(float(data[4]))))
            x_center = abs(round(int(x_min + (x_max - x_min) / 2)))
            y_center = abs(round(int(y_min + (y_max - y_min) / 2)))
            file = open(
                "C:\\Users\\Administrator\\Desktop\\Linh tinh\\Dataset\\yolov5\\evaluate_track\\id_14\\track\\track.txt",
                'a')
            file.write(f'{frame_id} {x_center} {y_center} {label}\n')


get_txt_track(path_track_txt, path_track, c, 33)

for image in os.listdir(path_track):
    c.append(image)
list_points = []
count = 200
file_txt = open(
    "C:\\Users\\Administrator\\Desktop\\Linh tinh\\Dataset\\yolov5\\evaluate_track\\id_14\\track\\track.txt")
file_datas = file_txt.readlines()
for line in file_datas:
    data = [x for x in line.split(" ")]
    frame_ids = int(data[0])
    x = int(data[1])
    y = int(data[2])
    pt = [x, y]
    list_points.append(pt)
    print(len(list_points))
    if len(list_points) <= 1:
        path_img0 = os.path.join(path_track, c[frame_ids])
        img0 = cv2.imread(path_img0)
        cv2.imshow("img", img0)
        cv2.waitKey(3)
        cv2.imwrite(os.path.join(save_track, "{:06d}.jpg".format(count)), img0)
        count += 1
    else:
        path_img = os.path.join(path_track, c[frame_ids])
        img = cv2.imread(path_img)
        for k in range(len(list_points) - 1):
            img = cv2.line(img, (list_points[k][0], list_points[k][1]),
                           (list_points[k + 1][0], list_points[k + 1][1]), color=(0, 0, 255), thickness=5)
        cv2.imwrite(os.path.join(save_track, "{:06d}.jpg".format(count)), img)
        count += 1
        cv2.imshow("img", img)
        cv2.waitKey(3)

# -------------------------------------------------------------------------------------------------------------------

# def get_images_gt(path, path0, lists, lists0, id):
#     for file in os.listdir(path):
#         lists.append(file)
#     for image in os.listdir(path0):
#         lists0.append(image)
#     m = 0
#     list_points = []
#     count = 0
#     for i in range(len(lists)):
#         path_annotations = os.path.join(path, lists[i])
#         gt_file = open(path_annotations, 'r')
#         data = json.load(gt_file)
#         obj = data['shapes']
#         for j in range(len(obj)):
#
#             label = int(obj[j]['label'])
#
#             point = obj[j]['points']
#
#             if label == id:
#                 x1 = point[0][0]
#                 y1 = point[0][1]
#                 x2 = point[1][0]
#                 y2 = point[1][1]
#
#                 x_min = abs(round(int(min(x1, x2))))
#                 x_max = abs(round(int(max(x1, x2))))
#                 y_min = abs(round(int(min(y1, y2))))
#                 y_max = abs(round(int(max(y1, y2))))
#
#                 x_center = abs(round(int(x_min + (x_max - x_min) / 2)))
#                 y_center = abs(round(int(y_min + (y_max - y_min) / 2)))
#                 file_gt = open("C:/Users/Administrator/Desktop/Linh tinh/Dataset/yolov5/evaluate_track/id_16/gt/gt.txt",
#                                'a')
#                 file_gt.write(f'{i} {x_center} {y_center} {label}\n')
#                 pt1 = [x_center, y_center]
#
#                 list_points.append(pt1)
#         if len(list_points) == 0:
#             continue
#
#         if len(list_points) == 1:
#             path_img0 = os.path.join(path0, lists0[i])
#             img0 = cv2.imread(path_img0)
#             cv2.imwrite(os.path.join(save_gt, "{:06d}.jpg".format(count)), img0)
#             count += 1
#             cv2.imshow("img", img0)
#             cv2.waitKey(3)
#         elif len(list_points) + 162 > i:
#             path_img = os.path.join(path0, lists0[i])
#             img = cv2.imread(path_img)
#             for k in range(len(list_points) - 1):
#                 img = cv2.line(img, (list_points[k][0], list_points[k][1]),
#                                (list_points[k + 1][0], list_points[k + 1][1]), color=(0, 255, 0), thickness=5)
#             cv2.imwrite(os.path.join(save_gt, "{:06d}.jpg".format(count)), img)
#             count += 1
#             cv2.imshow("img", img)
#             cv2.waitKey(3)
#
#
# get_images_gt(path_gt_annotations, path_gt, a, b, id=16)
