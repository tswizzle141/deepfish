import cv2
import os
import shutil

cap = cv2.VideoCapture("F:/Database/GH010371.MP4")
count = 0
# cap.set(cv2.CAP_PROP_FPS, 100)
# length = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
# fps = cap.get(cv2.CAP_PROP_FPS)

# print(length)
# print(fps)

path_video = "F:/Database/GH010371.MP4/"

dirs = path_video.split(".MP4")[0]
print(dirs)
# shutil.rmtree(dirs)
# os.mkdir(dirs)
frame_counter = 0
while cap.isOpened():
    ret, frame = cap.read()
    print(frame)
    if ret:
        # cv2.resize(frame, (1024, 1024))
        cv2.imshow('video', frame)
        cv2.waitKey(1)
#         cv2.imwrite(os.path.join(dirs, "GH_010371_{:05d}.jpg".format(count)), frame)
#         frame_counter += 1
#         count += 1
#         cap.set(1, frame_counter)
#     else:
#         cap.release()
#         break
# cap.release()





