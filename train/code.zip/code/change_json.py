import json
import os

path = "F:/Database/GH010371_annotations/"
path1 = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/yolov5/Bee/HoneyBee/"
j = 0


# for root, dirs, files in os.walk(path):
#     for file in files:
#         path_json = os.path.join(root, file)
#         json_file = open(path_json, "r")
#         data = json.load(json_file)
#         json_file.close()
#         # data['imageHeight'] = 416
#         # data['imageWidth'] = 416
#         # obj = data['shapes']
#         # print(obj)
#         # for i in range(0, len(obj)):
#         #     point = obj[i]['points']
#         #     point[0][0] = point[0][0] * (416 / 1280)
#         #     point[0][1] = point[0][1] * (416 / 720)
#         #     point[1][0] = point[1][0] * (416 / 1280)
#         #     point[1][1] = point[1][1] * (416 / 720)
#         # print(obj)
#         for root1, dirs1, files1 in os.walk(path1):
#             data['imagePath'] = os.path.join(root1, files1[j])
#             j += 1
#         print(data)
#         json_file = open(path_json, "w")
#         json.dump(data, json_file)
#         json_file.close()

# path = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/efficientdet/Bee/valid/instances_val.json"
# count = 141
# json_file = open(path, 'r')
# data = json.load(json_file)
# json_file.close()
# image = data['images']
# print(image)
# for i in range(len(image)):
#     image[i]['file_name'] = "{:06d}.jpg".format(count)
#     count += 1
#     json_file = open(path, "w")
#     json.dump(data, json_file)
#     json_file.close()

json_name_list = []
for file in os.listdir(path):
    if file.endswith(".json"):
        json_name_list.append(file)

for i in range(3990, 4001):
    path_json = path + json_name_list[i]
    path_json_pre = path + json_name_list[3989]
    json_file = open(path_json, 'r')
    json_data = json.load(json_file)
    json_file_pre = open(path_json_pre, 'r')
    json_data_pre = json.load(json_file_pre)
    json_file.close()
    json_file_pre.close()
    json_data['shapes'] = json_data_pre['shapes']
    # for j in range(len(obj)):
    #     label = obj[j]['label']
    #     pt = obj[j]['points']

        # if label != "2":
        #     obj[j]['label'] = "1"
    json_file = open(path_json, "w")
    json.dump(json_data, json_file)
    json_file.close()

