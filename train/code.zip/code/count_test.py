import cv2
import os
import math
import numpy as np

path_track = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/yolov5/yolov5-sort/HoneyBee"
path_track_txt = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/yolov5/yolov5-sort/results.txt"
track_test = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/yolov5/yolov5-sort/track_test.txt"
save_track = "F:/Database/Bee/evaluate_track"


def get_txt_track(path, path0, lists0, id):
    f = open(path)
    file_data = f.readlines()
    for line in file_data:
        data = [x for x in line.split(",")]
        frame_id = int(data[0])
        label = int(float(data[9].split("\n")[0]))
        if label == id:
            x_min = abs(round(int(float(data[1]))))
            y_min = abs(round(int(float(data[2]))))
            x_max = abs(round(int(float(data[3]))))
            y_max = abs(round(int(float(data[4]))))
            x_center = abs(round(int(x_min + (x_max - x_min) / 2)))
            y_center = abs(round(int(y_min + (y_max - y_min) / 2)))
            file = open(track_test, 'a')
            file.write(f'{frame_id} {x_center} {y_center} {label}\n')


def distance(p0, p1):
    return math.sqrt((p0[0] - p1[0]) ** 2 + (p0[1] - p1[1]) ** 2)


if __name__ == "__main__":
    count4 = 998
    fly_in = 0
    fly_out = 0
    crawl = 0
    for z in range(0, 128):
        c = []
        if os.path.exists(track_test):
            os.remove(track_test)
        get_txt_track(path_track_txt, path_track, c, z)

        for image in os.listdir(path_track):
            c.append(image)
        list_points = []
        point_y = []
        count1 = 0
        count2 = 0
        count3 = 0
        pt = [0, 0]
        if os.path.exists(track_test):
            file_txt = open(track_test, 'r')
            file_data = file_txt.readlines()
            for line in file_data:
                data = [x for x in line.split(" ")]
                frame_ids = int(data[0])
                x = int(data[1])
                y = int(data[2])
                point_y.append(y)
                pt = [x, y]
                list_points.append(pt)
                if len(list_points) <= 1:
                    path_img0 = os.path.join(path_track, c[frame_ids])
                    img0 = cv2.imread(path_img0)
                    cv2.imshow("img", img0)
                    cv2.waitKey(1)
                    # cv2.imwrite(os.path.join(save_track, "{:06d}.jpg".format(count4)), img0)
                    # count4 += 1
                else:
                    path_img = os.path.join(path_track, c[frame_ids])
                    img = cv2.imread(path_img)
                    for k in range(len(list_points) - 1):
                        img = cv2.line(img, (list_points[k][0], list_points[k][1]),
                                       (list_points[k + 1][0], list_points[k + 1][1]), color=(0, 0, 255), thickness=5)
                    # cv2.imwrite(os.path.join(save_track, "{:06d}.jpg".format(count4)), img)
                    # count4 += 1
                    cv2.imshow("img", img)
                    cv2.waitKey(1)

            if len(list_points) > 2:
                a = distance(list_points[0], list_points[1])
                b = distance(list_points[0], list_points[len(list_points) - 1])
                d = np.argmax(point_y)
                print("a : ", a)
                print("b : ", b)
                g = distance(list_points[0], list_points[d])
                h = distance(list_points[d], list_points[len(list_points) - 1])
                if b != 0 and max(g, h) != 0:
                    dis = round(a / b * 100, 2)
                    dis1 = round(min(g, h) / max(g, h) * 100, 2)
                    print("dis : ", dis)
                    print("dis1 : ", dis1)
                    for i in range(len(point_y) - 2):
                        if point_y[i] > point_y[0]:
                            count1 += 1

                        else:
                            count2 += 1

                        if point_y[i] >= point_y[i + 1] >= point_y[i + 2] or point_y[i] <= point_y[i + 1] <= point_y[
                            i + 2]:
                            continue
                        else:
                            count3 += 1

                    print("count1 : ", count1)
                    print("count2 : ", count2)
                    print(count3)
                    if max(count1, count2) != 0:
                        if max(count1, count2) < 149:
                            error = round(count3 / max(count1, count2) * 100, 2)
                            print(error)
                            if error <= 38 and dis <= 40 and dis1 <= 28:
                                if point_y[0] > point_y[len(point_y) - 1]:
                                    if point_y[0] >= 343 or 0 < list_points[0][0] <= 130:
                                        label = "flying_in"
                                        fly_in += 1
                                    else:
                                        label = "crawling"
                                        crawl += 1
                                else:
                                    if 223 <= point_y[0] <= 361:
                                        label = "flying_out"
                                        fly_out += 1
                                    else:
                                        label = "crawling"
                                        crawl += 1
                            else:
                                label = "crawling"
                                crawl += 1

                            img = cv2.putText(img, label, org=(100, 50), fontFace=cv2.FONT_HERSHEY_PLAIN, fontScale=3,
                                              color=(0, 255, 0), thickness=3)
                            # cv2.imshow("img", img)
                            # cv2.waitKey(100)
                            # cv2.imwrite(os.path.join(save_track, "{:06d}.jpg".format(count4)), img)
                            # count4 += 1
                            # t = 0
                            # while (t < 20):
                            #     # cv2.imwrite(os.path.join(save_track, "{:06d}.jpg".format(count4)), img)
                            #     # count4 += 1
                            #     t += 1
                        else:
                            error = round(count3 / max(count1, count2) * 100, 2)
                            print(error)
                            if error <= 9 and dis1 <= 30 and dis <= 25:
                                if point_y[0] > point_y[len(point_y) - 1]:
                                    if point_y[0] >= 343 or 0 < list_points[0][0] <= 130:
                                        label = "flying_in"
                                        fly_in += 1
                                    else:
                                        label = "crawling"
                                        crawl += 1
                                else:
                                    if 223 <= point_y[0] <= 361:
                                        label = "flying_out"
                                        fly_out += 1
                                    else:
                                        label = "crawling"
                                        crawl += 1
                            else:
                                label = "crawling"
                                crawl += 1

                            img = cv2.putText(img, label, org=(100, 50), fontFace=cv2.FONT_HERSHEY_PLAIN, fontScale=3,
                                              color=(0, 255, 0), thickness=3)
                            # cv2.imshow("img", img)
                            # cv2.waitKey(100)
                            # cv2.imwrite(os.path.join(save_track, "{:06d}.jpg".format(count4)), img)
                            # count4 += 1
                            # t = 0
                            # while (t < 20):
                            #     cv2.imwrite(os.path.join(save_track, "{:06d}.jpg".format(count4)), img)
                            #     count4 += 1
                            #     t += 1
                    else:
                        pass
                else:
                    pass

            else:
                pass
            file_txt.close()

    print(crawl)
    print(fly_in)
    print(fly_out)
