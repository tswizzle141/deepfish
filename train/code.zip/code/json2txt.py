import os
import json

path = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/HoneyBee2_annotations/"