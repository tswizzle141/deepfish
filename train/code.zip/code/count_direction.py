import os
import numpy as np
import cv2
import numpy as np
import math

path_image = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/yolov5/yolov5-sort/HoneyBee/005067.jpg"
path_txt = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/yolov5/yolov5-sort/track_sum.txt"
path_save = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/yolov5/yolov5-sort/HoneyBee/"
file_txt = open(path_txt)
ID = []
flying_out = 0
flying_in = 0
crawling = 0


def distance(p0, p1):
    return math.sqrt((p0[0] - p1[0]) ** 2 + (p0[1] - p1[1]) ** 2)


file_data = file_txt.readlines()
for line in file_data:
    data = [x for x in line.split(" ")]
    id = int(data[3])
    ID.append(id)
ID = set(ID)
print(len(ID))
for i in range(1, max(ID) + 1):
    point_y = []
    list_points = []
    count = 0
    count1 = 0
    count2 = 0
    for line in file_data:
        data = [x for x in line.split(" ")]
        id = int(data[3])
        if id == i:
            frame_id = int(data[0])
            x = int(data[1])
            y = int(data[2])
            pt = [x, y]
            list_points.append(pt)
            point_y.append(y)
        else:
            pass
    if len(list_points) > 2:
        a = distance(list_points[0], list_points[1])
        b = distance(list_points[0], list_points[len(list_points) - 1])
        d = np.argmax(point_y)
        # print("a : ", a)
        # print("b : ", b)
        # print("dis : ", dis)
        g = distance(list_points[0], list_points[d])
        h = distance(list_points[d], list_points[len(list_points) - 1])
        if b != 0 and max(g, h) != 0:
            dis = round(a / b * 100, 2)
            dis1 = round(min(g, h) / max(g, h) * 100, 2)
            # print("dis1 : ", dis1)
            for j in range(len(point_y) - 2):
                if point_y[j] > point_y[0]:
                    count1 += 1
                else:
                    count2 += 1
                if point_y[j] >= point_y[j + 1] >= point_y[j + 2] or point_y[j] <= point_y[j + 1] <= point_y[j + 2]:
                    continue
                else:
                    count += 1

            if max(count1, count2) != 0:
                if max(count1, count2) < 149:
                    error = round(count / max(count1, count2) * 100, 2)
                    if error <= 38 and dis <= 40 and dis1 <= 28:
                        if point_y[0] > point_y[len(point_y) - 1]:
                            if point_y[0] >= 343 or 0 < list_points[0][0] <= 130:
                                flying_in += 1
                            else:
                                crawling += 1
                        else:
                            if 223 <= point_y[0] <= 361:
                                flying_out += 1
                            else:
                                crawling += 1
                    else:
                        crawling += 1
                else:
                    error = round(count / max(count1, count2) * 100, 2)
                    if error <= 9 and dis1 <= 30 and dis <= 25:
                        if point_y[0] > point_y[len(point_y) - 1]:
                            if point_y[0] >= 343 or 0 < list_points[0][0] <= 130:
                                flying_in += 1
                            else:
                                crawling += 1
                        else:
                            if 223 <= point_y[0] <= 361:
                                flying_out += 1
                            else:
                                crawling += 1
                    else:
                        crawling += 1
            else:
                pass
        else:
            pass
print(flying_out)
print(flying_in)
print(crawling)
label1 = f'flying_in : {flying_in}'
label2 = f'flying_out : {flying_out}'
label3 = f'crawling : {crawling}'
img = cv2.imread(path_image)
cv2.putText(img, label1, org=(100, 50), fontFace=cv2.FONT_HERSHEY_PLAIN, fontScale=3,
            color=(0, 255, 0), thickness=3)
cv2.putText(img, label2, org=(100, 100), fontFace=cv2.FONT_HERSHEY_PLAIN, fontScale=3,
            color=(255, 0, 0), thickness=3)
cv2.putText(img, label3, org=(100, 150), fontFace=cv2.FONT_HERSHEY_PLAIN, fontScale=3,
            color=(0, 0, 255), thickness=3)
k = 50680
while (k < 50780):
    cv2.imwrite(os.path.join(path_save, "{:06d}.jpg".format(k)), img)
    k += 1
