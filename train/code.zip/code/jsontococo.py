import labelme2coco
label_folder = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/train_ann"
save_json_path = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/_annotations.coco.json"
labelme2coco.convert(label_folder, save_json_path)
