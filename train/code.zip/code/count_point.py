import cv2
import os
import numpy as np

path_txt = "F:/Database/Bee/evaluate_track/id_16/track/track.txt"
point = []
count1 = 0
count2 = 0
count3 = 0
file_txt = open(path_txt)
file_data = file_txt.readlines()
for line in file_data:
    data = [x for x in line.split(" ")]
    frame_id = int(data[0])
    x = int(data[1])
    y = int(data[2])
    point.append(y)
    id = int(data[3])

for i in range(len(point) - 2):
    if point[i] > point[0]:
        count1 += 1
    else:
        count2 += 1
    if point[i] >= point[i + 1] >= point[i + 2] or point[i] <= point[i + 1] <= point[i + 2]:
        continue
    else:
        count3 += 1
print(count1)
print(count2)
print(count3)
error = round(count3 / max(count1, count2) * 100, 2)
print(error)
