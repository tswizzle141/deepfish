# thuật toán : chạm line => cho den khi ko cham và track van con => đi ra count+1 và bỏ qua obj
# chạm line và sau 3 frame mất track => đi vào
# (175, 253); (1280, 253)

# d = []
# # memory = [5, 6, 7, 8, 9]
# previous = [5, 6, 7, 8]
# memory = [5, 6, 9]
# a = set(set(previous).intersection(memory))
# print(a)
# for r in range(len(memory)):
#     print(memory[r])
# if set(set(previous).intersection(memory)):
#     print("true")
# if len(a) != len(previous):
#     b = set(memory).symmetric_difference(previous)
#     c = b - set(b).intersection(memory)
#     print(a)
#     print(b)
#     print(c)
#     for x in c:
#         print(x)
#
# else:
#     print("pass")
import cv2
import imutils

path = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/HoneyBee1.mp4"
path1 = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/HoneyBee2.mp4"
vs = cv2.VideoCapture(path)
vs1 = cv2.VideoCapture(path1)
prop = cv2.CAP_PROP_FRAME_COUNT
total = int(vs.get(prop))
print("[INFO] {} total frames in video".format(total))
a = 0
while True:  # for every frame
    current_frame = vs.get(cv2.CAP_PROP_POS_FRAMES)
    vs.set(1, current_frame)
    (grabbed, frame) = vs.read()
    print("current : ", current_frame)
    print(frame)
    # cv2.imshow("img", frame)
    # cv2.waitKey(100)
    k = 0
    curr_frame = current_frame

    while (k < 2):
        curr_frame = curr_frame + 1
        vs1.set(cv2.CAP_PROP_POS_FRAMES, curr_frame)
        ret, frames = vs1.read()
        print("curr : ", curr_frame)
        print(frames)
        k += 1


    # print("curr : ", current_frame)
    # print(frame)
    # k += 1
    # vs.set(1, current_frame - 1)
    if not grabbed:
        break
