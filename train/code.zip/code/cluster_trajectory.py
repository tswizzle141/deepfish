import cv2
import os

path_track_txt = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/yolov5/yolov5-sort/results.txt"
path_track = "C:/Users/Administrator/Desktop/Linh tinh/Dataset/yolov5/yolov5-sort/HoneyBee"
save_path = "C:\\Users\\Administrator\\Desktop\\Linh tinh\\Dataset\\yolov5\\yolov5-sort\\results_track"
c = []
frame_ids = []
# f = open(path_track_txt)
# file_data = f.readlines()
# for line in file_data:
#     data = [x for x in line.split(",")]
#     frame_id = int(data[0])
#     label = int(float(data[9].split("\n")[0]))
#
#     x_min = abs(round(int(float(data[1]))))
#     y_min = abs(round(int(float(data[2]))))
#     x_max = abs(round(int(float(data[3]))))
#     y_max = abs(round(int(float(data[4]))))
#
#     x_center = abs(round(int(x_min + (x_max - x_min) / 2)))
#     y_center = abs(round(int(y_min + (y_max - y_min) / 2)))
#     file = open(
#         "C:\\Users\\Administrator\\Desktop\\Linh tinh\\Dataset\\yolov5\\yolov5-sort\\track.txt",
#         'a')
#     file.write(f'{frame_id} {x_center} {y_center} {label}\n')

for image in os.listdir(path_track):
    c.append(image)
count = 0
list_points = []
point = []
ID = []
file_txt = open("C:\\Users\\Administrator\\Desktop\\Linh tinh\\Dataset\\yolov5\\yolov5-sort\\track.txt")
file_data = file_txt.readlines()
for line in file_data:
    data = [x for x in line.split(" ")]
    frame_id = int(data[0])
    frame_ids.append(frame_id)
    x = int(data[1])
    y = int(data[2])
    id = int(data[3])
    ID.append(id)
# for i in range(1, max(ID) + 1):
#     for line in file_data:
#         data = [x for x in line.split(" ")]
#         frame_id = int(data[0])
#         x = int(data[1])
#         y = int(data[2])
#         id = int(data[3])
#         if id == i:
#             file = open(
#                 "C:\\Users\\Administrator\\Desktop\\Linh tinh\\Dataset\\yolov5\\yolov5-sort\\track1.txt",
#                 'a')
#             file.write(f'{frame_id} {x} {y} {i}\n')

# for i in range(0, max(frame_ids) - 1, 5):
#     point_copy = point.copy()
#     point = []
#     for line in file_data:
#         data = [x for x in line.split(" ")]
#         frame_ids = int(data[0])
#         if frame_ids == i:
#             x = int(data[1])
#             y = int(data[2])
#             id = int(data[3])
#             dict = {f'{id}': y}
#             point.append(dict)
#         else:
#             continue
#     print(i)
#     print(point)


for i in range(601):
    # list_copy = list_points.copy()
    # print(list_copy)
    list_points = []
    for line in file_data:
        data = [x for x in line.split(" ")]
        frame_ids = int(data[0])
        if frame_ids == i:
            x = int(data[1])
            y = int(data[2])
            pt = [x, y]
            id = int(data[3])
            dict = {f'{id}': pt}
            list_points.append(dict)
        else:
            continue
    print(i)
    print(list_points)
    point.append(list_points)
    print(point)
    if len(point) <= 1:
        path_img0 = os.path.join(path_track, c[0])
        img0 = cv2.imread(path_img0)
        cv2.imshow("img", img0)
        cv2.waitKey(3)
        cv2.imwrite(os.path.join(save_path, "{:06d}.jpg".format(count)), img0)
        count += 1
    else:
        path_img = os.path.join(path_track, c[i])
        img = cv2.imread(path_img)
        for k in range(len(point) - 1):
            for j in point[k]:
                count1 = 0
                for h in point[k + 1]:
                    if j.keys() == h.keys():
                        count1 += 1
                        pt1 = j.values()
                        pt2 = h.values()
                        pt3 = list(pt1)
                        pt4 = list(pt2)
                        img = cv2.line(img, (int(pt3[0][0]), int(pt3[0][1])), (int(pt4[0][0]), int(pt4[0][1])),
                                       color=(0, 255, 0), thickness=3)
                    else:
                        continue
                if count1 == 0:
                    for k1 in point:
                        for k2 in k1:
                            if k2.keys() == j.keys():
                                k1.remove(k2)
                else:
                    pass

        cv2.imshow("img", img)
        cv2.waitKey(3)
        cv2.imwrite(os.path.join(save_path, "{:06d}.jpg".format(count)), img)
        count += 1


