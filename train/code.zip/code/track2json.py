import json
import cv2
import os

null = None
a = []
i = 0
count = 0
json_path = "F:/Database/GH010371_170_290_annotations/"
txt_path = "F:/Database/reindex_2_hands.txt"
content = {"version": "4.5.6", "flags": {}}

json_name_list = []
for file in os.listdir(json_path):
    if file.endswith(".json"):
        json_name_list.append(file)

f = open(txt_path, 'r')
f_data = f.readlines()
for j in range(1, 3599):
    for line in f_data:
        data = [x for x in line.split(", ")]
        frame_id = int(data[0])
        if j == frame_id:
            # label = int(float((data[1].split("\n")[0])))
            # x_min = abs(round(int(float(data[1]))))
            # y_min = abs(round(int(float(data[2]))))
            # x_max = abs(round(int(float(data[3]))))
            # y_max = abs(round(int(float(data[4]))))
            label = int(float((data[1])))
            x_min = abs(round(int(float(data[2]))))
            y_min = abs(round(int(float(data[3]))))
            x_max = x_min + abs(round(int(float(data[4]))))
            y_max = y_min + abs(round(int(float(data[5]))))
            w, h = 1280, 720
            dict = {
                "label": f'{label}',
                "points": [
                    [
                        x_min,
                        y_max
                    ],
                    [
                        x_max,
                        y_min
                    ]
                ],
                "group_id": null,
                "shape_type": "rectangle",
                "flags": {}
            }
            a.append(dict)
        else:
            continue

    path_json = json_path + json_name_list[i]
    json_file = open(path_json, 'r')
    json_data = json.load(json_file)
    json_file.close()
    f.close()
    json_data['shapes'] = a
    json_data["imagePath"] = "../GH010371_170_290/GH010371_{:05d}.jpg".format(count)
    json_data["imageData"] = null
    json_data["imageHeight"] = 1440
    json_data["imageWidth"] = 1920
    json_file = open(path_json, "w")
    json.dump(json_data, json_file)
    json_file.close()
    a = []
    i += 1
    count = count + 1
